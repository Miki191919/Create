```markdown
# Create — pełniejszy prototyp

Zawiera:
- Backend: FastAPI + SQLite + JWT (role-based auth: admin/vip/user)
- Frontend: React skeleton z logowaniem, listą projektów, edytorem (miejsce dla Blockly)
- Docker Compose do szybkiego uruchomienia

Szybkie uruchomienie lokalne (dev):
1. Skopiuj repozytorium.
2. W katalogu głównym uruchom:
   docker-compose up --build
3. Backend dostępny: http://localhost:8000
   Frontend dostępny: http://localhost:3000

Dev notes:
- Domyślny admin jest bootstrapowany z .env (tylko do testów). Zmień hasło w produkcji.
- JWT secret w .env — w produkcji użyj secret store.
- Frontend zapisuje token JWT w localStorage (dla prototypu). W produkcji stosuj bezpieczniejsze podejście.

Dalsze kroki:
- Osadzić Blockly w src/components/Editor.jsx (z komentarzami).
- Rozszerzyć walidację slug/random_id i generowanie czytelnych share URL.
- Dodać testy integracyjne i jednostkowe.
```