import React from "react";

/*
  Editor placeholder.
  Tu osadź Blockly lub inny edytor blokowy.
  W produkcji:
  - Zainstaluj: react-blockly lub bezpośrednio google/blockly
  - Skonfiguruj kategorie: Events, Control, Motion, Looks, Sound, Sensing, Operators, Variables, MyBlocks
  - Mapuj bloki do JSON scripts (scena.sprites[].scripts)
  - Dodaj mechanizm podglądu -> serializacja do project.scene

  Przykład integracji (skrót):
  import Blockly from 'blockly';
  <BlocklyComponent ... />
*/

export default function Editor({ project }) {
  return (
    <div style={{ border: "1px solid #ddd", padding: 8, marginTop: 8 }}>
      <strong>Editor (placeholder)</strong>
      <div>Project: {project.name}</div>
      <div style={{ width: 480, height: 360, background: "#eef", marginTop: 8 }}>
        Canvas 480×360 - podgląd sceny (placeholder)
      </div>
      <p style={{ fontSize: 12, color: "#666" }}>
        Tu zaimplementuj przeciąganie bloków (Blockly). Po zapisie zserializuj skrypt do project.scene i wyślij do backendu.
      </p>
    </div>
  );
}