import React, { useEffect, useState } from "react";
import { postToken, apiGet, apiPost } from "./api";
import Editor from "./components/Editor";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || null);
  const [me, setMe] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loginForm, setLoginForm] = useState({ login: "", password: "" });
  const [newProj, setNewProj] = useState({ name: "", custom_slug: "" });

  useEffect(() => {
    if (token) {
      localStorage.setItem("token", token);
      fetchMe();
      fetchProjects();
    } else {
      localStorage.removeItem("token");
    }
  }, [token]);

  async function fetchMe() {
    try {
      const data = await apiGet("/me", token);
      setMe(data);
    } catch (e) {
      console.error(e);
      setToken(null);
    }
  }

  async function fetchProjects() {
    try {
      const data = await apiGet("/projects", token);
      setProjects(data);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleLogin(e) {
    e.preventDefault();
    try {
      const data = await postToken(loginForm.login, loginForm.password);
      setToken(data.access_token);
    } catch (err) {
      alert("Login failed: " + err.message);
    }
  }

  async function handleCreateProject(e) {
    e.preventDefault();
    if (!me) return alert("Zaloguj się");
    try {
      const payload = {
        owner_id: me.id,
        name: newProj.name,
        custom_slug: newProj.custom_slug || null,
        is_public: true,
        scene: {}
      };
      await apiPost("/projects", payload, token);
      fetchProjects();
      setNewProj({ name: "", custom_slug: "" });
    } catch (err) {
      alert("Create project failed: " + err.message);
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <header style={{ display: "flex", gap: 20, alignItems: "center" }}>
        <h1>Create — prototype</h1>
        {me ? <div>Witaj, {me.login} ({me.roles.join(",")})</div> : <div>Nie zalogowany</div>}
      </header>

      {!token ? (
        <section style={{ marginTop: 20 }}>
          <h2>Logowanie</h2>
          <form onSubmit={handleLogin}>
            <input placeholder="login" value={loginForm.login} onChange={e => setLoginForm({ ...loginForm, login: e.target.value })} />
            <input placeholder="hasło" type="password" value={loginForm.password} onChange={e => setLoginForm({ ...loginForm, password: e.target.value })} />
            <button type="submit">Zaloguj</button>
          </form>
        </section>
      ) : (
        <section style={{ marginTop: 20 }}>
          <button onClick={() => { setToken(null); setMe(null); }}>Wyloguj</button>

          <h2>Utwórz projekt</h2>
          <form onSubmit={handleCreateProject}>
            <input placeholder="Nazwa projektu" value={newProj.name} onChange={e => setNewProj({ ...newProj, name: e.target.value })} required />
            <input placeholder="Custom slug (VIP only)" value={newProj.custom_slug} onChange={e => setNewProj({ ...newProj, custom_slug: e.target.value })} />
            <button type="submit">Stwórz</button>
          </form>

          <h2>Twoje projekty / Wszystkie projekty</h2>
          <ul>
            {projects.map(p => (
              <li key={p.id}>
                {p.name} — {p.status} — {p.slug ? `slug:${p.slug}` : `id:${p.random_id}`}
                <div>share: {p.slug ? `${window.location.origin}/game/${p.slug}` : `${window.location.origin}/game/${p.random_id}`}</div>
                <Editor project={p} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

export default App;