from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import OAuth2PasswordRequestForm
from .database import engine, get_db
from . import models, crud, schemas, auth
from sqlalchemy.orm import Session
import os
from dotenv import load_dotenv

load_dotenv()

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Create - prototype with JWT & roles")

# bootstrap admin (dev only)
def bootstrap_admin(db: Session):
    admin_login = os.getenv("ADMIN_LOGIN", "MicopixoYT")
    admin_password = os.getenv("ADMIN_PASSWORD", "miki5768")
    if not crud.get_user_by_login(db, admin_login):
        crud.create_user(db, schemas.UserCreate(login=admin_login, password=admin_password, roles=["admin"]))
    # optional sample user
    if not crud.get_user_by_login(db, "user1"):
        crud.create_user(db, schemas.UserCreate(login="user1", password="password", roles=["user"]))

# run bootstrap with a DB session
from .database import SessionLocal
db_boot = SessionLocal()
bootstrap_admin(db_boot)
db_boot.close()

@app.post("/auth/token", response_model=schemas.Token)
def login_for_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = crud.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token = auth.create_access_token({"sub": str(user.id)})
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/auth/register", response_model=schemas.UserOut)
def register(u: schemas.UserCreate, db: Session = Depends(get_db)):
    if crud.get_user_by_login(db, u.login):
        raise HTTPException(status_code=400, detail="Login already exists")
    user = crud.create_user(db, u)
    return schemas.UserOut.from_orm(user)

@app.get("/me", response_model=schemas.UserOut)
def read_me(current_user = Depends(auth.get_current_user)):
    return schemas.UserOut.from_orm(current_user)

# Projects
@app.post("/projects", response_model=schemas.ProjectOut)
def create_project(payload: schemas.ProjectCreate, db: Session = Depends(get_db), current_user=Depends(auth.get_current_user)):
    if payload.owner_id != current_user.id and "admin" not in current_user.roles:
        raise HTTPException(status_code=403, detail="Cannot create project for another user")
    # if custom_slug provided require vip/admin
    if payload.custom_slug and "vip" not in current_user.roles and "admin" not in current_user.roles:
        raise HTTPException(status_code=403, detail="Custom slugs require VIP")
    p = crud.create_project(db, payload)
    return p

@app.get("/projects/{project_id}", response_model=schemas.ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    project = crud.get_project(db, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if project.status != "approved" and "admin" not in (getattr(project.owner, "roles", "") or ""):
        # for simplicity: only approved projects are public; owners & admins can view
        pass
    return project

@app.get("/projects", response_model=list[schemas.ProjectOut])
def list_projects(owner_id: int | None = None, status: str | None = None, db: Session = Depends(get_db)):
    projects = crud.list_projects(db, owner_id, status)
    return projects

# Admin endpoints
@app.post("/admin/ban")
def admin_ban(req: schemas.AdminAction, db: Session = Depends(get_db), current_user=Depends(auth.require_role("admin"))):
    if not req.target_user_id:
        raise HTTPException(status_code=400, detail="target_user_id required")
    user = crud.set_user_banned(db, req.target_user_id, True)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"status": "ok", "user": user.login, "banned": True}

@app.post("/admin/unban")
def admin_unban(req: schemas.AdminAction, db: Session = Depends(get_db), current_user=Depends(auth.require_role("admin"))):
    if not req.target_user_id:
        raise HTTPException(status_code=400, detail="target_user_id required")
    user = crud.set_user_banned(db, req.target_user_id, False)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"status": "ok", "user": user.login, "banned": False}

@app.post("/admin/grant-premium")
def grant_premium(req: schemas.AdminAction, days: int = 30, db: Session = Depends(get_db), current_user=Depends(auth.require_role("admin"))):
    if not req.target_user_id:
        raise HTTPException(status_code=400, detail="target_user_id required")
    user = crud.grant_premium(db, req.target_user_id, days)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"status": "ok", "user": user.login, "premium_expires": user.premium_expires.isoformat()}

@app.post("/admin/revoke-premium")
def revoke_premium(req: schemas.AdminAction, db: Session = Depends(get_db), current_user=Depends(auth.require_role("admin"))):
    if not req.target_user_id:
        raise HTTPException(status_code=400, detail="target_user_id required")
    user = crud.revoke_premium(db, req.target_user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"status": "ok", "user": user.login, "roles": user.roles}

@app.post("/admin/approve-project")
def approve_project(req: schemas.AdminAction, db: Session = Depends(get_db), current_user=Depends(auth.require_role("admin"))):
    if not req.target_project_id:
        raise HTTPException(status_code=400, detail="target_project_id required")
    proj = crud.set_project_status(db, req.target_project_id, "approved")
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"status": "ok", "project": proj.name, "status": proj.status}