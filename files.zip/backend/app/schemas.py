from pydantic import BaseModel
from typing import Optional, List, Any
import datetime

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserCreate(BaseModel):
    login: str
    password: str
    roles: Optional[List[str]] = ["user"]

class UserOut(BaseModel):
    id: int
    login: str
    roles: List[str]
    is_banned: bool
    premium_expires: Optional[datetime.datetime] = None

    class Config:
        orm_mode = True

class UserAuth(BaseModel):
    login: str
    password: str

class ProjectCreate(BaseModel):
    owner_id: int
    name: str
    custom_slug: Optional[str] = None
    is_public: bool = False
    scene: Optional[Any] = {}

class ProjectOut(BaseModel):
    id: int
    owner_id: int
    name: str
    slug: Optional[str]
    random_id: str
    is_public: bool
    status: str
    scene: Any

    class Config:
        orm_mode = True

class AdminAction(BaseModel):
    target_user_id: Optional[int] = None
    target_project_id: Optional[int] = None

class ProjectListQuery(BaseModel):
    owner_id: Optional[int] = None
    status: Optional[str] = None