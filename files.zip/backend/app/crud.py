from .models import User, Project
from .schemas import UserCreate, ProjectCreate
from sqlalchemy.orm import Session
from passlib.context import CryptContext
import secrets
import datetime

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_user_by_login(db: Session, login: str):
    return db.query(User).filter(User.login == login).first()

def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()

def create_user(db: Session, user: UserCreate):
    hashed = pwd_context.hash(user.password)
    u = User(login=user.login, password_hash=hashed, roles=",".join(user.roles))
    db.add(u)
    db.commit()
    db.refresh(u)
    return u

def authenticate_user(db: Session, login: str, password: str):
    user = get_user_by_login(db, login)
    if not user:
        return None
    if pwd_context.verify(password, user.password_hash):
        return user
    return None

def create_project(db: Session, payload: ProjectCreate):
    # generate random id if no slug provided
    rand = secrets.token_hex(8)
    slug = payload.custom_slug if payload.custom_slug else None
    p = Project(owner_id=payload.owner_id, name=payload.name, slug=slug, random_id=rand, is_public=payload.is_public, scene=payload.scene)
    db.add(p)
    db.commit()
    db.refresh(p)
    return p

def get_project(db: Session, project_id: int):
    return db.query(Project).filter(Project.id == project_id).first()

def list_projects(db: Session, owner_id: int | None = None, status: str | None = None):
    q = db.query(Project)
    if owner_id is not None:
        q = q.filter(Project.owner_id == owner_id)
    if status:
        q = q.filter(Project.status == status)
    return q.all()

def set_user_banned(db: Session, user_id: int, banned: bool = True):
    user = get_user(db, user_id)
    if not user:
        return None
    user.is_banned = banned
    db.commit()
    return user

def grant_premium(db: Session, user_id: int, days: int = 30):
    user = get_user(db, user_id)
    if not user:
        return None
    now = datetime.datetime.utcnow()
    if user.premium_expires and user.premium_expires > now:
        user.premium_expires = user.premium_expires + datetime.timedelta(days=days)
    else:
        user.premium_expires = now + datetime.timedelta(days=days)
    roles = set(user.roles.split(",")) if user.roles else set()
    roles.add("vip")
    user.roles = ",".join(roles)
    db.commit()
    return user

def revoke_premium(db: Session, user_id: int):
    user = get_user(db, user_id)
    if not user:
        return None
    roles = set(user.roles.split(",")) if user.roles else set()
    roles.discard("vip")
    user.roles = ",".join(roles)
    user.premium_expires = None
    db.commit()
    return user

def set_project_status(db: Session, project_id: int, status: str):
    proj = get_project(db, project_id)
    if not proj:
        return None
    proj.status = status
    db.commit()
    return proj