from sqlalchemy import Column, Integer, String, Boolean, JSON, ForeignKey, DateTime
from sqlalchemy.orm import declarative_base, relationship
import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    login = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    roles = Column(String, default="user")  # CSV: "admin,vip,user"
    is_banned = Column(Boolean, default=False)
    premium_expires = Column(DateTime, nullable=True)

    projects = relationship("Project", back_populates="owner")

    def roles_list(self):
        return self.roles.split(",") if self.roles else []

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"))
    owner = relationship("User", back_populates="projects")
    name = Column(String, nullable=False)
    slug = Column(String, unique=True, nullable=True)
    random_id = Column(String, unique=True, nullable=False)
    is_public = Column(Boolean, default=False)
    status = Column(String, default="pending")  # pending/approved/rejected
    scene = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.datetime.utcnow)